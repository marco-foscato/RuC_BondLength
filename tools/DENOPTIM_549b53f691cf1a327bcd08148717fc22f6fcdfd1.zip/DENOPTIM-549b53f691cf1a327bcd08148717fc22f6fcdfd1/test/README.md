#
# README file for test folder of DENOPTIM
# 

=> PtCOLX2: published test case for evolutionary experiments.

=> PtCOLX2_FSE: test case for exhaustive exploration of fragment space

=> functional_tests: dummy runs of various components of the DENOPTIM package
                     meant to verify the functionality of the code. Require
                     <code>bash</code> and <code>python</code> commands to be
                     in the $PATH.

