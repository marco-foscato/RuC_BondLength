# CHANGELOG

## From 1.0.1 to 1.1.0
* Introduction of GUI

* Keywords changed:

  * DenoptimCG:

    * <code>GA-SortOrder</code> replaced by <code>GA-SortByIncreasingFitness</code>, which is a flag that takes null argument.

    * <code>GA-ReplacementStrategy</code> argument changed to string (NONE or ELITIST).

    * <code>GA-Parallelization</code> argument changed to string (synchronous or asynchronous).

    *

  * DenoptimGA:

    * <code>GA-FitnessEvalScript</code> removed. Use <code>FP-Source</code> and <code>FP-Interpreter</code>

  * DenoptimRND: 

  * FragSpaceExplorer:

    * <code>FSE-ExternalTask</code> removed. Use <code>FP-Source</code> and <code>FP-Interpreter</code>


