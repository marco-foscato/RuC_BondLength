package autocompchem.chemsoftware.generic;

/*   
 *   Copyright (C) 2016  Marco Foscato 
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Affero General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Affero General Public License for more details.
 *
 *   You should have received a copy of the GNU Affero General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import autocompchem.chemsoftware.errorhandling.ErrorManager;
import autocompchem.chemsoftware.errorhandling.ErrorMessage;
import autocompchem.files.FileAnalyzer;
import autocompchem.files.FileUtils;
import autocompchem.io.IOtools;
import autocompchem.run.Terminator;
import autocompchem.worker.TaskID;
import autocompchem.worker.Worker;

/**
 * Reader and analyzer of GenericTool Output files. A defined list of 
 * {@link ErrorMessage}s can be recognized and interpreted.<br>
 * The evaluation requires the following parameters:
 * <ul>
 * <li>
 * <b>{@value autocompchem.chemsoftware.generic.GenericToolConstants#INPUTFILENAMEKEY}</b>: path or name of the output from GenericTool. Usually, the
 * log or output file of the GenericTool.
 * </li>
 * <li>
 * <b>{@value autocompchem.chemsoftware.generic.GenericToolConstants#ERRORTREEROOTKEY}</b>: path to the folder storing GenericTool known 
 * {@link ErrorMessage}s.
 * </li>
 * <li>
 * <b>{@value autocompchem.chemsoftware.generic.GenericToolConstants#VERBOSITYKEY}</b>: verbosity level.
 * </li>
 * </ul>
 * 
 * @author Marco Foscato
 */

public class GenericToolOutputHandler extends Worker
{
    /**
     * Declaration of the capabilities of this subclass of {@link Worker}.
     */
    public static final Set<TaskID> capabilities =
            Collections.unmodifiableSet(new HashSet<TaskID>(
                    Arrays.asList(TaskID.EVALUATEGENERICOUTPUT)));	
	
    /**
     * Name of the output file from GenericTool: the input of this class
     */
    private String inFile;

    /**
     * List of known error messages
     */
    private ArrayList<ErrorMessage> errorDef;

    /**
     * Verbosity level
     */
    private int verbosity = 1;

    /**
     * Total number Steps found (1-to-n) in the output from GenericTool
     */
    private int numSteps;

    /**
     * Flag recording normal termination of the GenericTool job
     */
    private boolean normalTermiated;

    /**
     * Flag recording whether the error is understood
     */
    private boolean errorIsDecoded;

    /**
     * The class corresponding to the error found in the GenericTool output
     */
    private ErrorMessage actualEM;

    /**
     * Counters found and current value
     */
    private Map<String,Integer> counters = new HashMap<String,Integer>();

    /**
     * Local storage of parameters
     */
    private GenericToolParameters gtParams = new GenericToolParameters();

//-----------------------------------------------------------------------------

    /**
     * Initialise the worker according to the parameters loaded by constructor.
     */

    @Override
    public void initialize()
    {
        gtParams = new GenericToolParameters(params);

        //Define verbosity
        if (params.contains(GenericToolConstants.VERBOSITYKEY))
        {
            String s = params.getParameter(
                       GenericToolConstants.VERBOSITYKEY).getValue().toString();
            this.verbosity = Integer.parseInt(s);
        }
        if (verbosity > 0)
        {
            System.out.println(" Adding params to GenericToolOutputHandler");
        }

        //Get and check the input file (which is an output from GenericTool)
        this.inFile = params.getParameter(
                   GenericToolConstants.INPUTFILENAMEKEY).getValue().toString();
        FileUtils.foundAndPermissions(this.inFile,true,false,false);

        //Get and check the list of known errors
        String errDefPath = params.getParameter(
                   GenericToolConstants.ERRORTREEROOTKEY).getValue().toString();
        if (verbosity > 0)
        {
            System.out.println(" Importing known errors from " + errDefPath);
        }
        FileUtils.foundAndPermissions(errDefPath,true,false,false);
        this.errorDef = ErrorManager.getAll(errDefPath);
    }

//-----------------------------------------------------------------------------

    /**
     * Performs any of the registered tasks according to how this worker
     * has been initialised.
     */

    @SuppressWarnings("incomplete-switch")
    @Override
    public void performTask()
    {
        switch (task)
          {
          case EVALUATEGENERICOUTPUT:
        	  evaluateGenericOutput();
              break;
          }

        if (exposedOutputCollector != null)
        {
/*
//TODO
            String refName = "";
            exposeOutputData(new NamedData(refName,
                  NamedDataType.DOUBLE, ));
*/
        }
    }


//------------------------------------------------------------------------------

    /**
     * Analyses the input file and identify its properties. This method is meant
     * to look into an ouptut/log file searching properties as
     * termination status, number
     * steps, type of error, and so on.
     */

    public void evaluateGenericOutput()
    {
        //Read the outfile and collect counts and line numbers
        ArrayList<String> patterns = new ArrayList<String>();
        patterns.add(gtParams.getOutputInitialMsg());
        patterns.add(gtParams.getOutputNormalEndMsg());
        ArrayList<ArrayList<Integer>> countsAndLineNum = 
                                           FileAnalyzer.count(inFile,patterns);
        int indexOfCounts = countsAndLineNum.size() - 1;
        ArrayList<Integer> counts = countsAndLineNum.get(indexOfCounts);
        ArrayList<ArrayList<Integer>> lineNums = 
                                            new ArrayList<ArrayList<Integer>>();
        //Keep all but the last array
        for (int i=0; i<(countsAndLineNum.size() - 1); i++)
        {
            lineNums.add(countsAndLineNum.get(i));
        }

        numSteps = counts.get(0); // # of "initiatin job" strings
        int numNormTerm = counts.get(1); // # of "normal termination" strings

        if (verbosity > 0)
        {
            System.out.println(" GenericTool output file contains: " 
                                      + numSteps + " steps");
        }

        if (numSteps == 0)
        {
            if (verbosity > 0)
            {
                Terminator.withMsgAndStatus("ERROR! Could not identify the "
                    + "beginning of any step in the output/log file provided. "
                    + "Are you sure the beginning of each step is identified "
                    + "by the string '"
                    + gtParams.getOutputInitialMsg() + "'?",-1);
            }
        }

        //Error identififcation
        if (numSteps != numNormTerm)
        {
            normalTermiated = false;

            if (verbosity > 0)
            {
                System.out.println(" The job did not terminate normally ");
                System.out.println(" Attempting identification of error...");
            }

            //Get the last part of the .out file (to get a smaller array)
            int lastInit = lineNums.get(0).get(numSteps - 1 );
            ArrayList<String> tail = IOtools.tailFrom(inFile,lastInit);

            //Compare with known errors
            identifyErrorMessage(tail);

            //Report
            if (verbosity > 0)
            {
                if (errorIsDecoded)
                {
                    System.out.println(" GenericTool Error Recognized: Step "  
                                        + numSteps
                                        + " returned Error Message: "
                                        + actualEM.getName());
                } else {
                    System.out.println(" GenericTool Error NOT Recognized. "
                                + "Please "
                                + "identify the error by hand and then add a "
                                + "new ErrorMessage to the list of known "
                                + "errors.");
                }
            }
        } else {
            normalTermiated = true;
        }  
    }

//------------------------------------------------------------------------------

    /**
     * Analize the output and identify the error (if this is known)
     * @param tail the portion of GenericTool output file corresponding to the 
     * last step
     */

    private void identifyErrorMessage(ArrayList<String> tail)
    {
        errorIsDecoded = false;
        for (ErrorMessage em : errorDef)
        {
            //Get the error message of this candidate error
            ArrayList<String> emLines = em.getErrorMessage();
            int numParts = emLines.size();

            if (verbosity > 1)
                System.out.println(" -> Trying with "+em.getName()+" <-");

            //Read .out file from bottom to top        looking for the error messages
            int numFound = 0;
            for (int i=(tail.size() - 1); i>-1; i--)
            {
                String line = tail.get(i);
                line = line.trim();
                for (String emLine : emLines)
                {
                    if (verbosity > 4)
                    {
                        System.out.println("Comparing line: \n_"
                                            + line
                                            + "_\n_"
                                            + emLine + "_");
                    }

                    if (line.contains(emLine))
                    {
                        numFound++;
                        if (verbosity > 2)
                        {
                            System.out.println("Error message '" + emLine 
                                                                + "' found");
                        }
                        break;
                    }
                }
                if (numFound == numParts)
                {
                    errorIsDecoded = true;
                    actualEM = em;
                    break;
                }
            } //end loop over tail lines

            if (errorIsDecoded)
            {
                //Are there other conditions this .out has to fulfill?
                ArrayList<String> conditions = em.getConditions();
                int numberOfConditions = conditions.size();
                if (numberOfConditions != 0)
                {
                    int numTrue = 0;
                    for (String cond : conditions)
                    {
                        String[] p = cond.split("\\s+");
                        String task = p[0];
                        task = task.toUpperCase();

                        boolean isSatisfied = false;
                        switch (task)
                        {
                            case "MATCH" :
                            {
                                String pattern = cond.substring(task.length());
                                String[] pp = pattern.split("\"");
                                pattern = pp[1];
                                pattern = pattern.toUpperCase();
                                if (verbosity > 2)
                                {
                                    System.out.println("Attempt to match '" 
                                                              + pattern + "'.");
                                }
                                for (int it=0; it<tail.size(); it++)
                                {
                                    String line = tail.get(it);
                                    line = line.toUpperCase();
                                    if (line.contains(pattern))
                                    {
                                        isSatisfied = true;
                                        if (verbosity > 2)
                                        {
                                            System.out.println("MATCH "
                                                + "condition satisfied by "
                                                + "text '" + line + "'");
                                        }
                                        break;
                                    }
                                }
                                break;
                            }
                            case "NOTMATCH" :
                            {
                                boolean patternFound = false;
                                String pattern = cond.substring(task.length());
                                String[] pp = pattern.split("\"");
                                pattern = pp[1];
                                pattern = pattern.toUpperCase();
                                for (int it=0; it<tail.size(); it++)
                                {
                                    String line = tail.get(it);
                                    line = line.toUpperCase();
                                    if (line.contains(pattern))
                                    {
                                        patternFound = true;
                                        if (verbosity > 2)
                                        {
                                            System.out.println("NOTMATCH "
                                                + "condition can NOT be "
                                                + "satisfied. Pattern found "
                                                + "in test '" + line + "'");
                                        }
                                        break;
                                    }
                                }
                                if (!patternFound)
                                {
                                    isSatisfied = true;
                                    if (verbosity > 2)
                                    {
                                        System.out.println("NOTMATCH condition "
                                                + "satisfied.");
                                    }
                                }
                                break;
                            }

                            case "CHECK_COUNTER":  
                                //Condition meant for loops with a named index
                                //Get identifier and limit of counter
                                String counterName = cond.substring(
                                                                 task.length());
                                String[] pp = counterName.split("\"");
                                counterName = pp[1];
                                counterName = counterName.toUpperCase();
                                int counterLimit = -1;
                                try {
                                    counterLimit = Integer.parseInt(p[2]);
                                } catch (Throwable t) {
                                    Terminator.withMsgAndStatus("ERROR! "
                                        + "Unable to read loop limit in error " 
                                        + em.getName(),-1);
                                }

                                //Get the current value of the counter
                                int counterValue = -1;
                                for (int it=0; it<tail.size(); it++)
                                {
                                    String line = tail.get(it);
                                    line = line.toUpperCase();
                                    if (line.contains(counterName))
                                    {
                                        if (verbosity > 2)
                                        {
                                            System.out.println("Counter " 
                                                + counterName + " found!");
                                        }
                                        String[] words = line.split("\\s+");
                                        for (int iw=0; iw<words.length; iw++)
                                        {
                                            String w = words[iw];
                                            if (w.contains(counterName))
                                            {
                                                String[] ppp = w.split("=");
                                                try {
                                                    counterValue = 
                                                       Integer.parseInt(ppp[1]);
                                                } catch (Throwable t) {
                                                        Terminator.withMsgAndStatus(
                                                        "ERROR! Unable to read "
                                                        + "value of counter "
                                                        + counterName + " in "
                                                        + w,-1);
                                                }
                                                break;
                                            }
                                        }

                                        //Make sure we got the number
                                        if (counterValue < 0)
                                        {
                                            Terminator.withMsgAndStatus(
                                                "ERROR! "
                                                + "Unable to read loop index "
                                                + "value in " + line,-1);
                                        }
                                    
                                        break;
                                    } 
                                }

                                //Check condition
                                if (counterValue >= counterLimit)
                                {
                                    Terminator.withMsgAndStatus("Maximum "
                                        + "number of cycles reaches for " 
                                        + em.getName() + ". " + counterName
                                        + " = " + counterValue + " (limit="
                                        + counterLimit +").",-1);
                                } else if (counterValue > 0) {
                                    if (verbosity > 2)
                                    {
                                        System.out.println(" Counter '" 
                                        + counterName
                                        + "' is still within the limit (next "
                                        + "iteration will have index "
                                        + (counterValue + 1) + " <= " 
                                        + counterLimit + ").");
                                    }
                                    counters.put(counterName,counterValue);
                                    isSatisfied = true;
                                } else {
                                    if (verbosity > 2)
                                    {
                                        System.out.println(" Check counter "
                                            + "condition is not verified: " 
                                            + "counter "
                                            + counterName + " not found.");
                                    }
                                }
                                break;

/*
TODO add other tasks here
                            case "":
                                ...do something...
                                break;

*/

                            default:
                                Terminator.withMsgAndStatus("ERROR! Condition "
                                        + task + " not known! "
                                        + "Check definition of error " 
                                        + em.getName(),-1);
                        }
                                        
                        if (!isSatisfied)
                            break;
                        else 
                            numTrue++;
                    }

                    if (numberOfConditions != numTrue)
                        errorIsDecoded = false;
                }

                //Nothing else to do if the error is identified
                if (errorIsDecoded)
                    break;
            }
        } //end loop over known errors

    }

//------------------------------------------------------------------------------

    /**
     * Method clarifying whether the error behind a not-normally terminated job
     * has been identified by this GenericToolOutputHandler or not.
     * @return <code>true</code> if GenericTool error message has been 
     * understood
     */

    public boolean isErrorUnderstood()
    {
        return errorIsDecoded;
    }

//------------------------------------------------------------------------------

    /**
     * Method returning the {@link ErrorMessage} of a not-normally terminated
     * job.
     * @return the ErrorMessage identified from GenericTool .out file
     */

    public ErrorMessage getErrorMessage()
    {
        return actualEM;
    }

//------------------------------------------------------------------------------

    /**
     * Method returning the number of steps represented in
     * the GenericTool output provided.
     * @return the number of steps identified in GenericTool .out file, which
     * is the index (1 to n) of the last step.
     */

    public int getNumberOfSteps()
    {
        return numSteps;
    }

//------------------------------------------------------------------------------

    /**
     * Method returning AutoCompChem counters stored in GenericTool output file.
     * @return the map of counters with counter names and values
     */

    public Map<String,Integer> getCounters()
    {
        return counters;
    }

//------------------------------------------------------------------------------

    /**
     * Returns a string summarizing the results of the evaluation 
     * @return the summary as a string
     */

    public String getResultsAsString()
    {
        String str = "File:" + inFile + " Steps:" + numSteps + " NormalTerm:"
                        + normalTermiated + " Error:";
        if (errorIsDecoded)
            str = str + actualEM.getName();
        else
            str = str + "Not Known";

        return str;
    }

//------------------------------------------------------------------------------

}
