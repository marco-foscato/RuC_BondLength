#/bin/bash
echo "BASH: START"
echo "1 is _${1}_"
echo "2 is _${2}_"
echo "3 is _${3}_"
echo "Tot is _$#_"
echo "BASH: DONE"
exit 0
