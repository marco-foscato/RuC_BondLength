#/bin/bash
echo "BASH: START"
sleep 2
echo "BASH: DONE"
exit 0
